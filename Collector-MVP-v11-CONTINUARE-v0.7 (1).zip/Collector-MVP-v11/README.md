# Collector MVP v11 — propagare locație populație, solduri și corecții append-only

## Pornire în Windows

1. Fă o copie de siguranță a folderului proiectului actual.
2. Oprește serverul local vechi (în fereastra în care rulează, `Ctrl+C`).
3. Extrage arhiva într-un folder separat.
4. Deschide terminalul în folderul `Collector-MVP-v6-core` și rulează:

   ```powershell
   py -m http.server 8000
   ```

   Dacă `py` nu funcționează, încearcă `python -m http.server 8000`.
5. Deschide `http://localhost:8000`.

**Important pentru datele existente:** `localStorage` este legat de origin (protocol + host + port), nu de folder. Folosirea aceluiași `http://localhost:8000` permite aplicației să citească jurnalul local existent și să migreze proiecțiile vechi. Dacă pornești pe alt port, browserul va vedea un spațiu de stocare separat. Înainte de schimbare, păstrează folderul vechi ca backup.

## Modificări v7

- Ierarhia locațiilor folosește relația direcțională `Conține`: seră → raft, cameră → dulap. Locațiile sunt spații stabile; nu se tratează ca obiecte mutate. Căile vechi create prin `located_in` rămân citibile pentru compatibilitate.
- Populațiile create cu locație inițială primesc atât soldul inițial, cât și relația temporală `Localizat în`; mutarea ulterioară actualizează locația și păstrează istoricul.
- Formularul de relații explică semnificația tipurilor și direcția sursă → destinație; `Localizat în` filtrează destinațiile la locații și dezactivează locațiile ca sursă.
- Tipul personalizat are câmp separat și obligatoriu numai când este selectat; textul nu mai înlocuiește accidental un tip standard. Motorul validează numele tipului personalizat și previne ciclurile în ierarhia `Conține`.
- Corectarea unei înregistrări inițiale de populație cere cantitatea corectă (inclusiv 0), aplică doar diferența față de cantitatea inițială și păstrează entitatea și evenimentul original. Nu folosi corectarea pentru a șterge o populație.

## Ce implementează această versiune

- Motorul de domeniu separat de interfață (`engine.js`).
- Jurnal append-only de evenimente; înaintea fiecărei operații, proiecțiile sunt reconstruite din jurnal.
- Evenimente cu operații multiple, aplicate atomic: dacă o precondiție eșuează, nu se salvează nicio parte a operației.
- Entități universale și atribute configurabile (tip, rol, natură, proprietar, required, identificare, limite numerice, istoric temporal).
- Istoric temporal al valorilor, certitudine distinctă de valoare, grafice numerice și marcarea evenimentelor discrete.
- Relații ca obiecte de prim rang, localizare temporală, mutări și ierarhie de locații; ciclurile în ierarhie sunt blocate.
- Grupuri/populații cu cantitate anonimă, mutări, vânzări, pierderi și solduri calculate; soldul activ negativ este blocat.
- Înregistrări financiare asociate evenimentelor și totaluri calculate din jurnal.
- Idempotency key pentru aceeași comandă rapidă în intervalul de cinci minute.
- Corecții prin evenimente noi; pentru atribute, stocuri, tranzacții financiare și relații se creează compensări, iar evenimentul inițial rămâne în jurnal.
- Export/import JSON, verificare de replay și dictare vocală prin SpeechRecognition dacă browserul o suportă.
- Contextul de introducere rapidă expiră după 30 de minute; datele persistente nu sunt afectate.

## Limite care rămân explicite

- Nu există un model AI local/cloud conectat. Interpretarea comenzilor rapide este deterministă și limitată; comenzile ambigue sunt refuzate în loc să se ghicească.
- Voice-first este doar un început: dictarea depinde de suportul browserului, iar fluxul conversațional vocal complet nu este implementat.
- Nu există autentificare, multi-user, sincronizare cloud sau sincronizare automată între dispozitive.
- Invariantele și impact analysis sunt implementate pentru operațiile principale (în special cantități, locații, atribute), nu pentru orice regulă imaginabilă a unui domeniu.
- Nu există încă un sistem complet de module de cunoaștere AI per domeniu.
- Decizia D-044 din copia documentației disponibile este trunchiată după „O greșeală nu este eliminată prin rescrierea ist...”. Implementarea respectă principiul append-only, dar textul integral trebuie recuperat pentru audit semantic final.

## Teste

Rulează:

```powershell
node test-engine.js
```

Testele automate ale motorului acoperă istoric temporal, ierarhie de locații, prevenirea ciclurilor, solduri, atomicitate/rollback, corecții de stoc, tranzacții financiare, idempotency și replay.

## v8 — relații vizibile în Entități
- Detaliul unei entități afișează relațiile active de intrare și de ieșire, cu direcția sursă → destinație, tipul și data creării.
- Lista Entități afișează numărul relațiilor active pentru fiecare entitate.
- Modificarea este doar de afișare; nu migrează și nu șterge relațiile deja salvate.
- Validare: `node --check app.js` și `node test-engine.js` trec. Testarea completă în browser rămâne necesară.

## v8 — membri individuali ai populațiilor

Când se creează o relație activă `Conține` de la o entitate de tip `population`/`group` către un individ identificat (tip `individual`, `shrimp`, `crevette`, `crevet`, `crevete`, `organism` sau `organism_individual`), motorul asigură un sold activ de cel puțin 1 pentru populație. Dacă populația are deja un sold activ pozitiv, individul este tratat ca parte a cantității existente și nu se adaugă încă unul, evitând dubla numărare. Relația și orice ajustare de sold sunt reconstruite din același eveniment la replay. Relațiile active duplicate sunt respinse.

Validare suplimentară: `node test-engine.js` include un test pentru numărarea inițială a individului, replay și prevenirea dublării cantității existente.


## v10 — corectarea cantității fără anulare accidentală
- Butonul „Corectează” pentru o înregistrare inițială de stoc cere acum cantitatea corectă, nu doar o descriere.
- Se înregistrează numai diferența dintre cantitatea corectă și cea inițială; de exemplu, 10 → 8 aplică -2, iar 10 → 0 aplică -10.
- Evenimentul original și entitatea rămân în jurnal. Corecția este un eveniment nou.
- Pachetul include și `index.html` pentru deschidere locală; stocarea din `file://` este separată de `http://localhost:8000`. Pentru a păstra datele existente, exportă mai întâi copia JSON din versiunea folosită și import-o în versiunea nouă. Nu șterge versiunea veche până nu verifici datele importate.

Validare v10: `node --check app.js`, `node --check engine.js` și `node test-engine.js` trec. Interfața nu a fost încă verificată manual în browser pe calculatorul utilizatorului.


## v11 — deschidere directă
- Pentru pornire fără server, deschide prin dublu-click fișierul `index.html`.
- `index-server.html` păstrează pagina care folosește fișierele separate și serverul local.
- Datele salvate în browser pentru `localhost` pot fi separate de datele din `file://`; exportă/backup-ează datele înainte de a schimba modul de deschidere.


## Pornire recomandată — v11
1. Închide fereastra CMD în care rulează serverul vechi (dacă este deschisă).
2. Dublu-click pe `Porneste-Collector.bat`.
3. Se va deschide browserul la `http://localhost:8000/index-server.html`.

Acest mod păstrează aceeași origine `http://localhost:8000`, deci poate accesa datele deja salvate de aplicația de pe localhost. Nu deschide `index.html` direct dacă vrei aceleași date: `file://` are stocare separată.


## v11 corectat — propagare populație → entități
- Entitățile individuale care sunt membre ale unei populații/grup moștenesc locația activă a populației în proiecția afișată. O locație directă a individului are prioritate.
- Mutarea unei populații/grup înregistrează relația temporală nouă și mută compensatoriu toate soldurile active ale populației din locațiile vechi în locația nouă; jurnalul original rămâne păstrat.
- Proiecțiile de locație și sold sunt calculate din evenimente, astfel încât rezultatul rămâne consecvent după replay.
- Test nou v9: locația populației se propagă la membrii individuali, mutarea actualizează soldul și comportamentul supraviețuiește replay-ului.

Validare efectuată după modificare: `node --check engine.js`, `node --check app.js` și `node test-engine.js` trec. Testarea manuală în browserul utilizatorului rămâne necesară.

## v11 D-044 — audit și corecții extinse
- Corecțiile de stoc, vânzare, eliminare și financiar sunt evenimente compensatorii legate de evenimentul inițial.
- Corectarea unei mutări de populație revine la locația anterioară numai dacă mutarea corectată este încă mutarea curentă. Dacă a existat o mutare reală ulterioară, corecția nu o anulează și păstrează soldul la destinația ulterioară.
- Corectarea relațiilor create/închise și a atributelor relațiilor este legată de evenimentul original; corectarea unei relații de apartenență inversează și efectul automat asupra stocului.
- Corectarea unei redenumiri revine la numele anterior numai dacă nu există o redenumire ulterioară.
- Interfața nu mai oferă repetarea corecției generice pentru același eveniment. Operațiile pentru care nu există încă o inversare sigură sunt refuzate explicit, fără modificări parțiale.
- Test nou: `node test-corrections.js` acoperă corecții de stoc cu activitate ulterioară, financiar, mutări succesive, relații create/închise, apartenență populație–individ, atribute de relație, redenumiri, replay și rollback atomic.

Validare finală: `node --check app.js`, `node --check engine.js`, `node test-engine.js`, `node test-correction.js` și `node test-corrections.js` trec. ZIP-ul este verificat structural. Testarea manuală a interfeței în browserul utilizatorului nu a fost executată în acest mediu.

### Validarea importului

Înainte să înlocuiască datele locale, importul reconstruiește proiecțiile din jurnal și verifică dacă nu există erori de replay, evenimente neconfirmate sau diferențe între jurnal și proiecțiile exportate. Fișierele vechi cu jurnal incomplet pot fi respinse și necesită migrare separată. Păstrează întotdeauna un export de siguranță înainte de import.

## AI Foundation

Documentația și scheletul inițial al stratului AI sunt în `Collector-AI-Foundation-v0.1.md`, `AI-FOUNDATION-README.md` și directorul `ai/`. Implementarea curentă folosește un provider mock și nu conectează încă AI-ul la persistență sau la `engine.js`.

Rulează testele cu `npm test` (Node.js 18+).

## v11 — AI Foundation Core Port UI v0.3

- Core Port este conectat la fluxul „Introducere rapidă” pentru observații, setări de atribute deja definite și vânzări din populații.
- Fiecare comandă este transformată în `collector.command.v1`, simulată prin `preview()`, apoi executată numai după confirmarea utilizatorului.
- `localStorage` este store-ul durabil: noua stare este publicată în UI numai după ce scrierea locală reușește.
- Operațiile de stoc sunt marcate cu risc ridicat; idempotency folosește `event.intentKey`.
- `ai/core-port-browser.js` este încărcat de toate paginile HTML de pornire.
- Limitare: parserul este determinist și limitat; nu există încă provider LLM/AI conectat și nu toate formularele UI au fost mutate pe Core Port.
- Validare: `node --check app.js`, `node --check ai/core-port-browser.js` și `npm test`.
